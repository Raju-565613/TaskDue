TaskDue for Mac — first launch
================================

macOS blocks any app that isn't purchased through the App Store or
signed with a paid Apple Developer certificate — this app is neither,
so macOS will refuse to open it the first time. This is expected, not
a broken download.

STEP 1 — do this once:
  Double-click "Fix First Launch.command" in this folder.
  (If macOS warns about running a script from the internet, right-click
  it and choose Open instead of double-clicking, then confirm.)

STEP 2 — from then on:
  Double-click TaskDue.app like any other app. It opens in its own
  window with no browser bar, tabs, or address bar.

If step 1 still doesn't work, right-click TaskDue.app itself → Open →
Open (confirm in the dialog). That manually grants the same permission.
