#!/bin/bash
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "Clearing macOS's quarantine flag from TaskDue.app..."
xattr -cr "$DIR/TaskDue.app"
chmod +x "$DIR/TaskDue.app/Contents/MacOS/TaskDue"
echo ""
echo "Done. You can now double-click TaskDue.app normally — this only needs to run once."
echo "Press Enter to close this window."
read
