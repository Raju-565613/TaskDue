TaskDue for iPhone/iPad — how to install
============================================

This folder is meant to be hosted somewhere (like your GitHub Pages
site), not opened directly as a local file. Here's why: Safari's
"Add to Home Screen" only becomes a real full-screen installed app —
with working reminders — when the page is served over HTTPS. Opening
it straight from a local file (file://) doesn't count as a secure
context, so Safari treats it as a plain bookmark instead.

Recommended: open the live hosted version in Safari, then tap
Share (the square with an arrow up) → "Add to Home Screen".

If you do want to test this local copy first:
  1. Open index.html in Safari.
  2. Tap Share → "Add to Home Screen".
  3. It'll work, but reminders won't fire and it may not go fully
     full-screen — both of those work correctly once this same file
     is served from a real hosted URL instead.
