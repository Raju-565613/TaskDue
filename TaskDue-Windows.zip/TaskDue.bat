@echo off
setlocal enabledelayedexpansion
set "DIR=%~dp0"
set "APP=%DIR%app.html"
set "APPFWD=%APP:\=/%"
set "TARGET=file:///%APPFWD%"
set "ICON=%DIR%TaskDue.ico"

REM ---- Find Chrome or Edge by checking real install locations directly.
REM      (where.exe only checks PATH, and neither browser adds itself there.) ----
set "CANDIDATES[0]=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
set "CANDIDATES[1]=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
set "CANDIDATES[2]=%LocalAppData%\Google\Chrome\Application\chrome.exe"
set "CANDIDATES[3]=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
set "CANDIDATES[4]=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
set "CANDIDATES[5]=%LocalAppData%\Microsoft\Edge\Application\msedge.exe"

set "BROWSER="
for /L %%i in (0,1,5) do (
  if not defined BROWSER if exist "!CANDIDATES[%%i]!" set "BROWSER=!CANDIDATES[%%i]!"
)

REM ---- First run only: create a real Start Menu shortcut with TaskDue's own icon,
REM      so Search and the Start Menu show the app properly instead of this .bat's
REM      generic gear icon. A .bat file can never carry its own icon — a shortcut
REM      pointing at it can, so this creates one automatically instead of asking
REM      you to do it by hand. ----
set "SHORTCUT=%APPDATA%\Microsoft\Windows\Start Menu\Programs\TaskDue.lnk"
if not exist "%SHORTCUT%" (
  powershell -NoProfile -WindowStyle Hidden -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut('%SHORTCUT%'); $s.TargetPath='%~f0'; $s.WorkingDirectory='%DIR%'; $s.IconLocation='%ICON%'; $s.Description='TaskDue'; $s.Save()" >nul 2>nul
)

if not defined BROWSER (
  echo Chrome or Edge weren't found in their usual install locations, so this can't open in app mode.
  echo Opening in your default browser instead.
  start "" "%APP%"
  goto :eof
)

start "" "%BROWSER%" --app="%TARGET%" --window-size=1300,860
