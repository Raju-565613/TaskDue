TaskDue for Windows — first launch
=====================================

Windows SmartScreen blocks any .bat file that isn't from a recognized,
signed publisher — this one isn't, so you'll likely see a blue "Windows
protected your PC" screen the first time you run it. This is expected,
not a broken download.

STEP 1 — do this once:
  When you see "Windows protected your PC," click "More info", then
  click "Run anyway".

STEP 2 — from then on:
  Double-click TaskDue.bat like any other app. It opens in its own
  window with no browser bar, tabs, or address bar (requires Chrome
  or Edge to be installed).

About the icon:
  A .bat file can never carry its own icon — that's a Windows limit,
  not something this app can fix directly. So the first time you run
  TaskDue.bat, it automatically creates a proper Start Menu shortcut
  called "TaskDue" with the real icon attached. Search for "TaskDue"
  (not "TaskDue.bat") afterward and you'll see it. From there, you can
  right-click that shortcut and choose "Pin to Start" or "Pin to
  taskbar" for quick access — Windows doesn't allow apps to pin
  themselves automatically, so that one click is still needed.
