TaskDue for Android — how to install
========================================

This folder is meant to be hosted somewhere (like your GitHub Pages
site), not opened directly as a local file. Here's why: Android's
full "Install app" experience — offline caching, a real home-screen
icon, no browser bar — requires the page to be served over HTTPS.
Opening it straight from a local file (file://) doesn't count as a
secure context, so Chrome will only offer a basic bookmark shortcut
instead of a true install.

Recommended: open the live hosted version in Chrome, then tap the
⋮ menu → "Add to Home screen" or "Install app".

If you do want to test this local copy first:
  1. Open index.html in Chrome.
  2. Tap ⋮ → "Add to Home screen".
  3. It'll work, but as a basic shortcut rather than a full offline-
     capable install — that upgrade happens automatically once this
     same file is served from a real hosted URL instead.
